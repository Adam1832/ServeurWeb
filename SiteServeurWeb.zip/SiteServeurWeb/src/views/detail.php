<!DOCTYPE html>
<html lang="fr-FR">
    <head>
        <meta name="" >
        <meta description="">
        <title>Produit</title>
        <link rel="stylesheet" href="/SiteServeurWeb/public/style.css">
        <meta charset="utf-8">
    
    </head>
    <?php
require_once __DIR__ . '/header.php';
?>
    <body>
        <article id="ch1">
            <a style="text-decoration:none" target="_blank">
                <h2>Nike React Vision</h2>
                <img src="/SiteServeurWeb/public/images/chaussure1.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
          <br/>
        </article>

        <article id="ch2">
            <a style="text-decoration:none">
                <h2>Nike Running</h2>
                <img src="/SiteServeurWeb/public/images/chaussure2.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
            <br/>
        </article>

        <article id="ch3">
            <a style="text-decoration:none">
                <h2>Nike Air Force One</h2>
                <img src="/SiteServeurWeb/public/images/chaussure3.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
            <br/>
        </article>

        <article id="ch4">
            <a style="text-decoration: none;">
                <h2>Adidas White&Black</h2>
                <img src="/SiteServeurWeb/public/images/chaussure4.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
            <br/>
        </article>

        <article id="ch5">
            <a style="text-decoration:none">
                <h2>Asics Noir</h2>
                <img src="/SiteServeurWeb/public/images/chaussure5.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
            <br/>
        </article>

        <article id="ch6">
            <a style="text-decoration:none">
                <h2>Nike Mercurial Superfly 9</h2>
                <img src="/SiteServeurWeb/public/images/chaussure5.jpg" alt="chaussure" >
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum 
                consequatur quod minus debitis, doloribus provident ratione itaque nulla, 
                nihil beatae pariatur. Sapiente eaque incidunt possimus? Iste perspiciatis 
                expedita ipsa dolorum?
                </p>
            </a>
            <br/>
        </article>
    </body>
</html>
<?php
require_once __DIR__ . '/footer.php';
?>