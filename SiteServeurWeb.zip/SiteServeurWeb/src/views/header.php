<!DOCTYPE html>
<html lang="fr-FR">
<head>
    <meta name="">
    <meta description="">
    <title>Site FitInShoes</title>
    <link rel="stylesheet" href="/SiteServeurWeb/public/style.css">
    <meta charset="utf-8">
</head>
<body>
    <header>
    <div id="bar1">
            <h1>Site FitInShoes</h1>
            <nav>
                <a href="/SiteServeurWeb/src/views/home.php">Accueil</a>
                <a href="/SiteServeurWeb/src/views/produits.php">Produits</a>
                <a href="/SiteServeurWeb/src/views/panier.php">Panier</a>
                <a href="/SiteServeurWeb/src/views/connexion.php">Connexion</a>
                <a href="/SiteServeurWeb/src/views/inscription.php">Inscription
                    <img src="/SiteServeurWeb/public/images/user1.png" alt="image user" >
                </a>
            </nav>
    </div>
    </header>