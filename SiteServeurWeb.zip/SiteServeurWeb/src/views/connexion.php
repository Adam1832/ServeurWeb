<?php
require_once __DIR__ . '/header.php';
?>
<!DOCTYPE html>
<html lang="fr-FR">
    <head>
        <meta name="" >
        <meta description="">
        <title>Connexion</title>
        <link rel="stylesheet" href="/SiteServeurWeb/public/style.css">
        <meta charset="utf-8">
    
    </head>
    <body>
        <main>
            <h2>Connexion</h2>
            <form action="submit_inscription.php" method="POST">

                <label for="email">Adresse email :</label>
                <input type="email" id="email" name="email" required><br><br>
    
                <label for="password">Mot de passe :</label>
                <input type="password" id="password" name="password" required><br><br>

                <button type="submit">Se connecter</button>
            </form>
        </main>
    </body>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>

</html>
<?php
require_once __DIR__ . '/footer.php';
?>