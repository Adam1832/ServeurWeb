<!DOCTYPE html>
<html lang="fr-FR">
<head>
    <meta name="">
    <meta description="">
    <title>404 Not Found</title>
    <link rel="stylesheet" href="/SiteServeurWeb/public/style.css">
    <meta charset="utf-8">
</head>
<body>
    <h1>404 Not Found</h1>
    <a href="./"> Retournez à l'accueil</a>
</body>
</html>
