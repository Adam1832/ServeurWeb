<footer>
        <p>&copy; 2024 Site FitInShoes. Tous droits réservés.</p>
        <div id="twitter">
            <a href="https://x.com">
                <img src="/SiteServeurWeb/public/images/twitter.avif" alt="logo twitter">
            </a>
        </div>

        <div id="insta">
            <a href="https://instagram.com">
                <img src="/SiteServeurWeb/public/images/insta.jpg" alt="logo instagram">
            </a>
        </div>

        <div id="facebook">
            <a href="https://facebook.com">
                <img src="/SiteServeurWeb/public/images/facebook.png" alt="logo facebook">
            </a>
        </div>
    </footer>
</body>
</html>
